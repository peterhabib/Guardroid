package com.example.guardroid;

public class GetNews {
}
