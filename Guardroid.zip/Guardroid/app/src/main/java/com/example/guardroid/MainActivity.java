package com.example.guardroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {


    private String TAG = MainActivity.class.getSimpleName();
    private ListView list_view;
    ArrayList<HashMap<String, String>> newsList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        newsList = new ArrayList<>();
        list_view = (ListView) findViewById(R.id.list);

        new GetNews().execute();
    }

    private class GetNews extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            // TODO: make a request to the URL
            String url = "https://content.guardianapis.com/search?q=debate&tag=politics/politics&from-date=2014-01-01&api-key=test";
            String jsonString = "";
            try {
                jsonString = sh.makeHttpRequest(createUrl(url));
            } catch (IOException e) {
                return null;
            }

            Log.e(TAG, "Response from url: " + jsonString);
            if (jsonString != null) {
                try {
                    //TODO: Create a new JSONObject

                    JSONObject jsonObj = new JSONObject(jsonString);
                    JSONObject responseOBJ = jsonObj.getJSONObject("response");

                    // TODO: Get the JSON Array node
                    JSONArray news = responseOBJ.getJSONArray("results");

                    // looping through all Contacts
                    for (int i = 0; i < news.length(); i++) {
                        //TODO: get the JSONObject
                        JSONObject c = news.getJSONObject(i);
                        String sectionName = c.getString("sectionName");
                        String type = c.getString("type");
                        String webTitle = c.getString("webTitle");


                        // tmp hash map for a single pokemon
                        HashMap<String, String> singleNew = new HashMap<>();

                        // add each child node to HashMap key => value
                        singleNew.put("sectionName", sectionName);
                        singleNew.put("type", type);
                        singleNew.put("webTitle", webTitle);

                        // adding a pokemon to our pokemon list
                        newsList.add(singleNew);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });

                }

            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server.",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }



        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                return null;
            }
            return url;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            ListAdapter adapter = new SimpleAdapter(MainActivity.this, newsList,
                    R.layout.list_view, new String[]{"sectionName", "type", "webTitle"},
                    new int[]{R.id.sectionid, R.id.type, R.id.webtitle});
            list_view.setAdapter(adapter);
        }




    }
}